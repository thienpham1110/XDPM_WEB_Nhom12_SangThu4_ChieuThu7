<b>Email:</b> {{$mail}} 
<br>
<b>Khách hàng:</b> {{$name}}
<br>
<b>Nội dung:</b> {{$content}}